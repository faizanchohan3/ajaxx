<!doctype html>
<html lang="en">
  <head>
  	<title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="css/style.css">

	</head>
	<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-5">
					<h2 class="heading-section"  id="ff">  </h2>
				</div>
        <div class="search bar">
          <H4>SEARCH HERE</H4>
          <input id="search" type="text"/>
        </div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="table-wrap">

          <tr>
              <td id="header">
                <h1>Enter Data</h1>
              </td>
            </tr>
            <tr>
              <td id="table-form">

FIRST NAME: <input type="text" id="fname">
<input type="button" id="save-button" value="save">
              </td>
              <td></td>
            </tr>
						<table class="table" id="table">
						  <thead class="thead-dark">
						    <tr>
						      <th>ID no.</th>
						      <th>First Name</th>
					
						      <th>Action</th>
						    </tr>
						  </thead>
						  <tbody>
					
						    <tr class="alert" role="alert">
						      <th scope="row">004</th>
						      <td>John</td>
					
						      <td>
						      	<a href="#" class="close" data-dismiss="alert" aria-label="Close">
				            	<span aria-hidden="true"><i class="fa fa-close"></i></span>
				          	</a>
				        	</td>
						    </tr>
						   
						  </tbody>
						</table>
            <div class="btdn">
              <button class="btn-primary" id="btn">click</button>
            </div>
			<div class="pagination">

			<a class="active  btn-primary" id="1" href="">1</a>
			<a id="2" class="btn-primary" href="">2</a>
			<a id="3"  class="btn-primary" href="">3</a>
			</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>
<script type="text/javascript">
 
$(document).ready(function(){
 
  

  
 $("#save-button").on('click',function(e){
e.preventDefault();
var fname=$("#fname").val();
$.ajax({
url:"uploaddata",
type:"POST",
data:{
  fistname:fname,
"_token":"<?php echo e(csrf_token()); ?>",
},
success:function(response){
if(response==true){
 loadtable();

}else
{
  console.log('ddd');
}
}

});

});
$(document).on("click",".btn-delete",function(e){

  var DELETEDID=$(this).data('id');
 $.ajax({
   type:"POST",
   url:"deletedata",
   data:{
deleteid:DELETEDID,
    "_token":"<?php echo e(csrf_token()); ?>"
   },
   success:function(response){
if(response==true){
  loadtable();
 
}
   }
 });
    });
  function loadtable(){

$.ajax({
  data: {
        "_token": "<?php echo e(csrf_token()); ?>"
        },
url:"getdata",
type:"POST",
success:function(response){
$('tbody').html(response);
}
});

}

loadtable();
$("#search").on("keyup",function(e){
var tex=$(this).val();
$.ajax({
  url:"search",
type:"POST",
data:{
  "_token":"<?php echo e(csrf_token()); ?>",
text:tex,
},
success:function(response){
console.log(response);
$('tbody').html(response);

}
});

})

});

</script>
	</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ajaxtutorial/resources/views/welcome.blade.php ENDPATH**/ ?>