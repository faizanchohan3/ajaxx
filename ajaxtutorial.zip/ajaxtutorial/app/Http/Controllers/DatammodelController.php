<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\datammodel;
class DatammodelController extends Controller
{
    public function index(){
       $data=new datammodel();
   $record=$data->all();
$count=count($record);
$output="";
if($count>0)
{
foreach($record as $row)
{
$output.= '<tr class="alert" role="alert">
<th scope="row">'.$row->id.'</th>
<td>'.$row->firstname.'</td>
<td><button  class="btn-delete" style="background-color:red"   data-id='.$row->id.'>Delete</button></td>
<td>
</tr>';
}
}
else {
    
    $output.='
   <tr>
   
    <td>data not found</td>
    </tr>';
}
  
      
 

   echo $output;
    }


    public function create(Request $request){

$name=$request->fistname;
$data=new datammodel();
$data->firstname=$name;

$data->save();
return true;
}



public function delete(Request $request){
$id=$request->deleteid;
$get=datammodel::where('id',$id)->delete();
 
echo($get);
}


public function search(Request $request){
    $data=new datammodel();
    $forsearc=$request->text;
    $search=$data->where('firstname','LIKE',"%{$forsearc}%")->get();
     
$output="";
if(count($search)>0){
foreach( $search as $row)
{
$output.= '<tr class="alert" role="alert">
<th scope="row">'.$row->id.'</th>
<td>'.$row->firstname.'</td>
<td><button  class="btn-delete" style="background-color:red"   data-id='.$row->id.'>Delete</button></td>
<td>
</tr>';
}

  
      
 
}else {
return "data not found";
}
   echo $output;
}
}
